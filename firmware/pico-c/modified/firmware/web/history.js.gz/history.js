'use strict';

function setupHistory({session,enqueue}) {
  const el=id=>document.getElementById(id), canvas=el('historyChart'), selector=el('historySession');
  const phases=['Heating','Holding','Cooling','Draining','Idle','Circulating','Cooling thermoblock','Pump hold','Heating'];
  const series=[['wort_f','Wort','#1e5947'],['thermoblock_f','Thermoblock','#b45e34'],['target_f','Target','#765ba0']];
  let metadata=null, rows=[], fields=[], selected=0, wantedId=null, loading=false, run=0, generation=session().generation;
  let unit=session().temperature_unit==='C'?'C':'F';
  let geometry=null;
  const duration=ms=>{
    const seconds=Math.max(0,Math.floor(Number(ms)/1000));
    return Math.floor(seconds/3600)+':'+String(Math.floor(seconds/60)%60).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0');
  };
  const value=(row,name)=>row[fields.indexOf(name)];
  const temperature=(row,name)=>{
    const number=value(row,name);
    return !Number.isFinite(number) || (name==='target_f' && number===0)?null:unit==='C'?(number-32)*5/9:number;
  };
  const phase=row=>phases[value(row,'phase')] || 'Phase '+value(row,'phase');
  const discardRecording=()=>{
    metadata=null;rows=[];fields=[];selected=0;geometry=null;
    el('historyReadout').textContent='';el('historyValues').textContent='';
    el('historyPhases').replaceChildren();canvas.getContext('2d').clearRect(0,0,canvas.width,canvas.height);
  };
  const clear=()=>{
    discardRecording();wantedId=null;run++;selector.replaceChildren();
    el('historySummary').textContent='Connect to load recorded brews.';
  };
  const update=()=>{
    const connection=session();
    if (!connection.key || connection.generation!==generation) {clear();generation=connection.generation;}
    const nextUnit=connection.temperature_unit==='C'?'C':'F';
    if (nextUnit!==unit) {unit=nextUnit;if (rows.length) choose(selected);}
    el('historyRefresh').disabled=loading || !connection.connected;
    selector.disabled=loading || !connection.connected || !selector.options.length;
    for (const id of ['historyExportJson','historyExportCsv','historySample']) el(id).disabled=loading || !rows.length;
  };
  const request=async(path,connection,token)=>enqueue(async()=>{
    if (token!==run || connection.generation!==session().generation || !session().key) throw new Error('Connection changed.');
    const controller=new AbortController(), timer=setTimeout(()=>controller.abort(),6000);
    try {
      const reply=await fetch('/api/v1/history'+path,{headers:{Accept:'application/json',Authorization:'Bearer '+connection.key},
        cache:'no-store',credentials:'omit',redirect:'error',signal:controller.signal});
      const data=await reply.json();
      if (!reply.ok) {const error=new Error(data.message || data.error || 'History request failed.');error.status=reply.status;throw error;}
      return data;
    } finally {clearTimeout(timer);}
  });
  const draw=()=>{
    const context=canvas.getContext('2d'), width=Math.max(320,canvas.clientWidth || 1000), height=340;
    const ratio=window.devicePixelRatio || 1;
    if (canvas.width!==Math.round(width*ratio) || canvas.height!==Math.round(height*ratio)) {
      canvas.width=Math.round(width*ratio);canvas.height=Math.round(height*ratio);
    }
    context.setTransform(ratio,0,0,ratio,0,0);
    context.clearRect(0,0,width,height);geometry=null;
    if (!rows.length) return;
    const left=55, right=width-20, top=25, bottom=height-55;
    const first=Number(value(rows[0],'elapsed_ms')), last=Number(value(rows[rows.length-1],'elapsed_ms'));
    const span=Math.max(1000,last-first), readings=[];
    for (const row of rows) for (const [field] of series) if (temperature(row,field)!==null) readings.push(temperature(row,field));
    let low=0,high=212;
    if (readings.length) {low=Math.floor((Math.min(...readings)-5)/10)*10;high=Math.ceil((Math.max(...readings)+5)/10)*10;}
    const x=time=>left+(time-first)/span*(right-left), y=temp=>bottom-(temp-low)/(high-low)*(bottom-top);
    context.font='12px system-ui';context.lineWidth=1;
    series.forEach(([,label,color],index)=>{context.fillStyle=color;context.textAlign='left';context.fillText(label,left+index*105,14);});
    for (let tick=0;tick<=4;tick++) {
      const temp=low+(high-low)*tick/4, yy=y(temp);
      context.strokeStyle='#dce3dc';context.beginPath();context.moveTo(left,yy);context.lineTo(right,yy);context.stroke();
      context.fillStyle='#64746d';context.textAlign='right';context.fillText(temp.toFixed(0)+'°'+unit,left-8,yy+4);
      const time=first+span*tick/4;context.textAlign='center';context.fillText(duration(time),x(time),height-12);
    }
    let previous=rows[0], start=first;
    const band=(end,row)=>{
      const xx=x(start), ww=x(end)-xx;
      context.fillStyle=Number(value(row,'phase'))%2?'#dce9df':'#edf1e9';context.fillRect(xx,bottom+8,ww,15);
      if (ww>75) {context.fillStyle='#385a2e';context.textAlign='left';context.fillText(phase(row),xx+4,bottom+20,ww-8);}
    };
    for (const row of rows.slice(1)) if (value(row,'phase')!==value(previous,'phase')) {
      band(value(row,'elapsed_ms'),previous);start=value(row,'elapsed_ms');previous=row;
    }
    band(last,previous);
    rows.forEach((row,index)=>{
      if (index && (value(row,'flags')&16)) {
        const from=x(value(rows[index-1],'elapsed_ms')), to=x(value(row,'elapsed_ms'));
        context.fillStyle='#f3d7cb';context.fillRect(from,top,to-from,bottom-top+23);
      }
    });
    for (const [field,,color] of series) {
      context.strokeStyle=color;context.lineWidth=2;context.setLineDash(field==='target_f'?[5,4]:[]);context.beginPath();
      let line=false;
      for (const row of rows) {
        const temp=temperature(row,field);
        if (temp===null) {line=false;continue;}
        const xx=x(value(row,'elapsed_ms')), yy=y(temp);
        if (!line || (value(row,'flags')&16)) context.moveTo(xx,yy);else context.lineTo(xx,yy);
        line=true;
      }
      context.stroke();
    }
    context.setLineDash([]);context.strokeStyle='#64746d';context.lineWidth=1;
    const cursor=x(value(rows[selected],'elapsed_ms'));
    context.beginPath();context.moveTo(cursor,top);context.lineTo(cursor,bottom);context.stroke();
    geometry={left,right,first,span,width};
  };
  const choose=index=>{
    if (!rows.length) return;
    selected=Math.max(0,Math.min(rows.length-1,index));const row=rows[selected], flags=value(row,'flags');
    el('historySample').value=selected;
    const temperatures=series.map(([field,label])=>label+': '+(field==='target_f' && value(row,field)===0?'Unheated':temperature(row,field)!==null?temperature(row,field).toFixed(1)+'°'+unit:'unavailable'));
    el('historyReadout').textContent=duration(value(row,'elapsed_ms'))+' · '+temperatures.join(' · ')+' · '+phase(row);
    el('historyValues').textContent=JSON.stringify({...Object.fromEntries(fields.map((name,i)=>[name,row[i]])),
      ready:!!(flags&1),busy:!!(flags&2),stopped:!!(flags&4),filter_inserted:!!(flags&8),sampling_gap:!!(flags&16)},null,2);
    draw();
  };
  const render=()=>{
    const saved=metadata.persisted_record_count ?? rows.length;
    el('historySummary').textContent=(metadata.recipe_name || metadata.command || 'Brew')+' · '+metadata.state+' · '+
      duration(metadata.duration_ms)+' · '+rows.length+' readings ('+saved+' saved) · '+(metadata.gap_count || 0)+' gaps'+
      (metadata.truncated?' · Recording limit reached; later readings were not saved.':'')+
      (metadata.storage_error?' · Storage error.':'')+
      (metadata.recovered_after_restart?' · Interrupted by a restart; showing the saved recording.':'');
    el('historySample').max=Math.max(0,rows.length-1);
    const body=el('historyPhases');body.replaceChildren();let previous='';
    for (const row of rows) {
      const state=[value(row,'phase'),value(row,'current_step'),value(row,'compartment'),value(row,'flags')&28].join(':');
      if (state===previous) continue;previous=state;
      const tr=document.createElement('tr');
      const step=value(row,'current_step');
      for (const text of [duration(value(row,'elapsed_ms')),phase(row)+((value(row,'flags')&16)?' · gap':''),
        (step===255?'—':String(step+1))+' / compartment '+value(row,'compartment')]) {
        const td=document.createElement('td');td.textContent=text;tr.append(td);
      }
      body.append(tr);
    }
    if (rows.length) choose(Math.min(selected,rows.length-1));
    else {el('historyReadout').textContent='No readings yet.';el('historyValues').textContent='';draw();}
    update();
  };
  const load=async(retry=false)=>{
    if (loading || !session().connected) {update();return;}
    loading=true;const connection=session(), token=++run;update();
    const current=()=>token===run && connection.generation===session().generation && !!session().key;
    try {
      const inventory=await request('',connection,token);
      if (!current()) return;
      if (!inventory.available) {clear();el('historySummary').textContent='No brew has been recorded yet.';return;}
      const sessions=inventory.sessions || [inventory];
      if (!sessions.length) throw new Error('No recorded brew is available.');
      const chosen=sessions.find(item=>item.id===wantedId) || sessions[0];wantedId=chosen.id;
      if (metadata && metadata.id!==chosen.id) discardRecording();
      selector.replaceChildren();
      for (const item of sessions) selector.add(new Option('#'+item.id+' · '+(item.recipe_name || item.command || 'Brew')+' · '+item.state,item.id));
      selector.value=String(wantedId);
      const next={...chosen,fields:inventory.fields,sample_interval_ms:inventory.sample_interval_ms,
        checkpoint_interval_ms:inventory.checkpoint_interval_ms};
      if (!Number.isSafeInteger(next.record_count) || next.record_count<0 || next.record_count>10000) throw new Error('Unrecognized history length.');
      const collected=metadata?.id===next.id && rows.length<=next.record_count?rows.slice():[];
      const names=next.fields;
      if (!Array.isArray(names) || !names.includes('elapsed_ms') || !names.includes('flags')) throw new Error('Unrecognized history format.');
      while (collected.length<next.record_count) {
        const offset=collected.length;
        const page=await request('/samples/'+offset+'?id='+encodeURIComponent(next.id),connection,token);
        if (!current()) return;
        if (page.id!==next.id || page.offset!==offset || !Array.isArray(page.samples) || !page.samples.length ||
            page.samples.some(row=>!Array.isArray(row) || row.length!==names.length)) throw new Error('Incomplete history page.');
        collected.push(...page.samples.slice(0,next.record_count-offset));
        el('historySummary').textContent='Loading recorded brew: '+collected.length+' / '+next.record_count+' readings';
      }
      if (!current()) return;
      metadata=next;rows=collected;fields=names;render();
    } catch (error) {
      if (current()) {
        if (error.status===409 && !retry) {loading=false;return await load(true);}
        el('historySummary').textContent=error.name==='AbortError'?'History request timed out. Refresh to try again.':error.message;
      }
    } finally {loading=false;update();}
  };
  const download=format=>{
    if (!metadata || !rows.length || loading) return;
    const quote=value=>'"'+String(value ?? '').replaceAll('"','""')+'"';
    const content=format==='json'?JSON.stringify({metadata,samples:rows},null,2):
      [fields.map(quote).join(','),...rows.map(row=>row.map(quote).join(','))].join('\r\n');
    const url=URL.createObjectURL(new Blob([content],{type:format==='json'?'application/json':'text/csv;charset=utf-8'}));
    const link=document.createElement('a');link.href=url;link.download='pico-brew-'+metadata.id+'.'+format;
    link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  };
  el('historyRefresh').addEventListener('click',()=>load());
  selector.addEventListener('change',()=>{wantedId=Number(selector.value);discardRecording();load();});
  el('historySample').addEventListener('input',event=>choose(Number(event.target.value)));
  el('historyExportJson').addEventListener('click',()=>download('json'));
  el('historyExportCsv').addEventListener('click',()=>download('csv'));
  canvas.addEventListener('pointermove',event=>{
    if (!geometry || loading) return;
    const bounds=canvas.getBoundingClientRect(), px=(event.clientX-bounds.left)*geometry.width/bounds.width;
    const time=geometry.first+(px-geometry.left)/(geometry.right-geometry.left)*geometry.span;
    let nearest=0;
    for (let i=1;i<rows.length;i++) if (Math.abs(value(rows[i],'elapsed_ms')-time)<Math.abs(value(rows[nearest],'elapsed_ms')-time)) nearest=i;
    if (nearest!==selected) choose(nearest);
  });
  new ResizeObserver(()=>{if (rows.length) draw();}).observe(canvas);
  setInterval(()=>{if (!document.hidden && !el('history').hidden && session().connected) load();},15000);
  clear();update();
  return {activate:()=>load(),update};
}

// Measurement formatting shared by the overview and session views.
function temperature(value) {
  const number = Number(value);
  if (value === null || value === undefined || !Number.isFinite(number)) return '—';
  const unit = state.settings.temperature_unit;
  return (unit === 'C' ? (number-32)*5/9 : number).toFixed(1)+'°'+unit;
}
function duration(seconds) {
  if (!Number.isFinite(Number(seconds))) return '—';
  const value = Math.max(0, Math.floor(Number(seconds)));
  const minutes = Math.floor(value/60);
  return minutes+':'+String(value%60).padStart(2,'0');
}

'use strict';

function updateControls() {
  const ready = state.connected && state.status?.ready === true;
  const busy = !!state.status?.busy;
  const stopped = !!state.status?.stopped;
  const idlePhase = state.status?.phase === 4;
  const advertised = command => state.capabilities.includes(command);
  const available = ready && !state.pendingCommands;
  document.querySelectorAll('[data-encoder]').forEach(button => button.disabled = !available || !advertised('encoder'));
  $('encoderClick').disabled = !available || !advertised('encoder');
  $('brewRecipe').disabled = !available || busy || stopped;
  $('startRecipe').disabled = !available || busy || stopped || !advertised('brew') || !$('brewRecipe').value;
  $('program').disabled = !available || busy || stopped;
  $('runProgram').disabled = !available || busy || stopped || !$('program').value;
  $('stopButton').disabled = !ready || stopped || state.stopPending || !advertised('stop');
  $('clearStop').hidden = !stopped;
  $('clearStop').disabled = !available || busy || !idlePhase || !advertised('clear-stop');
  $('restartBrewer').hidden = !state.restartSupported;
  $('restartBrewer').disabled = !available || busy || stopped || !idlePhase;
  $('newRecipe').disabled = !available || busy;
  $('restoreRecipes').disabled = !available || busy || !state.restoreDefaults;
  $('saveRecipe').disabled = !available || busy;
  $('deleteRecipe').disabled = !available || busy || !state.editorId;
  $('saveSettings').disabled = !available || busy;
  apiExplorer?.update();
  brewHistory?.update();
}


async function sendCommand(body) {
  const stop = body.command === 'stop';
  if (!state.connected || !state.capabilities.includes(body.command) ||
      (stop ? state.stopPending : state.pendingCommands)) return;
  const generation = state.generation;
  state.pendingCommands++;
  if (stop) state.stopPending = true;
  updateControls();
  try {
    const reply = await api('/commands','POST',body);
    if (reply?.accepted !== true || reply.command !== body.command)
      throw new Error('The brewer did not confirm this command.');
    if (body.command !== 'encoder') notify(stop ? 'Stop requested.' : 'Command accepted.');
    renderStatus(await api('/status'));
  } catch (error) {
    if (generation === state.generation) notify(error.message,true);
  } finally {
    if (generation === state.generation) {
      state.pendingCommands--;
      if (stop) state.stopPending = false;
      updateControls();
    }
  }
}

async function restartBrewer() {
  if ($('restartBrewer').disabled || !state.restartSupported ||
      !confirm('Restart the brewer now? It will briefly disconnect.')) return;
  const generation = state.generation;
  state.pendingCommands++;
  updateControls();
  try {
    const reply = await api('/system/restart','POST',{});
    if (reply?.accepted !== true) throw new Error('The brewer did not confirm the restart.');
    state.status = null;
    notify('Restart requested. Waiting for the brewer to reconnect.');
  } catch (error) {
    if (generation === state.generation) notify(error.message,true);
  } finally {
    if (generation === state.generation) {
      state.pendingCommands--;
      updateControls();
    }
  }
}

'use strict';

function readRecipeFile(text) {
  const recipe=JSON.parse(text);
  // JSON.parse keeps the last repeated property. The firmware rejects ambiguous
  // objects. Track keys in each object after the browser has checked the syntax.
  const keys=[];
  for(const match of text.matchAll(/("(?:\\.|[^"\\])*")\s*:|"(?:\\.|[^"\\])*"|[{}]/g)) {
    if(match[0]==='{')keys.push(new Set());
    else if(match[0]==='}')keys.pop();
    else if(match[1]) {
      const key=JSON.parse(match[1]), current=keys[keys.length-1];
      if(current.has(key))throw new Error('The recipe contains a repeated field: '+key+'.');
      current.add(key);
    }
  }
  return recipe;
}

function recipeIssue(recipe) {
  const integer = (value,low,high) => Number.isInteger(value) && value>=low && value<=high;
  const label = (value,limit) => typeof value==='string' && value.length>0 && value.length<=limit && !/[^ -~]/.test(value);
  if (!recipe || !Array.isArray(recipe.steps) || typeof recipe.id!=='string' ||
      !recipe.id.length || recipe.id.length>20 || /[^a-zA-Z0-9_-]/.test(recipe.id))
    return 'Choose a Pico recipe with an ID of 1–20 letters, digits, hyphens or underscores.';
  if (!label(recipe.name,31)) return 'Use 1–31 printable ASCII characters for the recipe name.';
  if (Object.keys(recipe).some(key=>!['id','name','steps'].includes(key)))
    return 'This recipe includes unsupported fields.';
  if (!integer(recipe.steps.length,1,15)) return 'Use 1–15 brewing steps.';
  for (const [index, step] of recipe.steps.entries()) {
    const prefix='Step '+(index+1)+': ';
    if (!step || !label(step.name,21)) return prefix+'Use 1–21 printable ASCII characters for the name.';
    if (Object.keys(step).some(key=>!['name','location','target_f','minutes','drain_minutes'].includes(key)))
      return prefix+'This step includes unsupported fields.';
    if (!integer(step.location,1,6)) return prefix+'Choose a valid flow path.';
    if (step.target_f!==0 && !integer(step.target_f,60,212)) return prefix+'Use 0 °F for unheated circulation or a whole number from 60–212 °F.';
    if (!integer(step.minutes,0,599)) return prefix+'Use 0–599 whole minutes.';
    if ('drain_minutes' in step && !integer(step.drain_minutes,0,120)) return prefix+'Use 0–120 whole drain minutes.';
  }
  return '';
}

const flowPaths = ['Keg circulation', 'Mash', 'Hop addition 1', 'Hop addition 2', 'Hop addition 3', 'Hop addition 4'];

function addStep(step={name:'New step',location:1,target_f:152,minutes:20,drain_minutes:0}) {
  if ($('steps').children.length>=15) {notify('A recipe can contain up to 15 steps.',true);return;}
  const row=document.createElement('tr');
  const definitions=[['name','text',null,null],['location','select',1,6],['target_f','number',0,212],['minutes','number',0,599],['drain_minutes','number',0,120]];
  for (const [field,type,min,max] of definitions) {
    const cell=document.createElement('td');let input;
    if(type==='select') {input=document.createElement('select');flowPaths.forEach((label,index)=>input.add(new Option(label,String(index+1))));}
    else {input=document.createElement('input');input.type=type;if(type==='text'){input.maxLength=21;input.pattern='[ -~]+';input.title='Use printable ASCII characters';}else{input.min=min;input.max=max;input.step=1;}}
    input.dataset.field=field;input.required=true;input.value=step[field] ?? (field==='drain_minutes'?0:'');
    input.setAttribute('aria-label',field.replaceAll('_',' '));cell.append(input);row.append(cell);
  }
  const cell=document.createElement('td');const remove=document.createElement('button');remove.type='button';remove.className='remove';remove.textContent='×';remove.setAttribute('aria-label','Remove step');
  remove.addEventListener('click',()=>{row.remove();state.dirty=true;});cell.append(remove);row.append(cell);$('steps').append(row);
}

function editRecipe(recipe, existing=false) {
  state.editorId=existing ? recipe.id : null;state.dirty=false;
  $('recipeName').value=recipe.name || '';$('recipeId').value=recipe.id || '';$('recipeId').readOnly=existing;
  $('recipeId').dataset.auto=existing ? 'false' : 'true';
  $('editorHeading').textContent=existing ? 'Edit recipe' : 'New recipe';$('steps').replaceChildren();
  for(const step of recipe.steps || [{name:'Mash',location:2,target_f:152,minutes:60,drain_minutes:0}])addStep(step);
  updateControls();
}

async function loadRecipe(id) {
  if(state.dirty && !confirm('Discard the unsaved recipe changes?'))return;
  try {const recipe=await api('/recipes/'+encodeURIComponent(id));editRecipe({...recipe,id},true);notify('');}
  catch(error){notify(error.message,true);}
}

function recipeFromForm() {
  if(!$('recipeForm').reportValidity())return null;
  const steps=Array.from($('steps').children).map(row=>{
    const step={};row.querySelectorAll('[data-field]').forEach(input=>step[input.dataset.field]=input.dataset.field==='name'?input.value:Number(input.value));return step;
  });
  const recipe={id:$('recipeId').value,name:$('recipeName').value,steps};
  const issue=recipeIssue(recipe);
  if(issue){notify(issue,true);return null;}
  return recipe;
}
