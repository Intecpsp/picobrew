PicoBrew standalone reference package: picostill

These are explicit custom/reference artifacts, not an OEM full-device backup.
No hardware installation, flash geometry or runtime qualification is inferred.
The package tool has not connected to, flashed or erased a device.

manifest.json names each generated image, exact offset, maximum region and SHA-256.
Only those image ranges form the reference write set; no full-chip erase image is supplied.
Confirm the actual device flash capacity, wiring and partition contents against a complete
private backup before planning installation. Preserve the listed NVS/EEPROM/RF regions.
spiffs.bin is a verified empty, formatted filesystem for a clean reference installation.
Writing it replaces existing modified settings/history in that region.
Firmware startup never formats a failed mount or erases damaged NVS.

Provision the API key and Wi-Fi through the physical UART; no key/password is supplied.
See firmware/picostill/modified/README.md for controls, provisioning and model boundaries.
